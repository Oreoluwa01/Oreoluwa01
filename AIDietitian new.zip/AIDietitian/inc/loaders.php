<style type="text/css">
   #loaders{
        width: 100%;
        height: 100%;
        background: white;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 20000;
        opacity: 0.4;
        display: none;
    }
    #loaders img{
        display:block; 
        margin-left: auto; 
        margin-right: auto; 
        margin-top: 15%; 
        width:200px;
    }

</style>
<div id="loaders">
    <img src="images/loadings.gif">
    </div>
    <div class="modal fade" id="myModal" role="dialog" style="margin-top: 10%;">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-body text-center">
        <div id="inputHere">

        </div>
        </div>
      </div>
    </div>
  </div>