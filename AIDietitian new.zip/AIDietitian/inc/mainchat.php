<div class="content" id="content">
									<div class="container">
										<div class="col-md-12">
											<div id="others">
												
											</div>
											<div id="messloading" style="display: none">
												<div class="message">
													<img class="avatar-md" src="dist/img/avatars/user.png" data-toggle="tooltip" data-placement="top" title="Keith" alt="avatar">
													<div class="text-main">
														<div class="text-group">
															<div class="text typing">
																<div class="wave">
																	<span class="dot"></span>
																	<span class="dot"></span>
																	<span class="dot"></span>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>